# VisionPrompt 🔍

Upload any image → get the ultra-detailed AI prompt that created it.

## Setup (2 minutes)

### Step 1 — Add your API key
Open `server.js` and replace `YOUR_API_KEY_HERE` with your key:

```js
const ANTHROPIC_API_KEY = "sk-ant-api03-xxxxxxxx...";
```

Get a free API key at: https://console.anthropic.com/keys

### Step 2 — Run the server
You need Node.js installed (https://nodejs.org — free).

Open a terminal in this folder and run:

```bash
node server.js
```

You'll see:
```
  ╔══════════════════════════════════════╗
  ║        VisionPrompt Server           ║
  ╠══════════════════════════════════════╣
  ║  Running at http://localhost:3000    ║
  ║  Open this URL in your browser       ║
  ╚══════════════════════════════════════╝
```

### Step 3 — Open in browser
Go to: **http://localhost:3000**

Upload any image and click **Decode Image Prompt** ✅

---

## How it works

- `server.js` — Node.js backend that securely holds your API key and proxies requests to Anthropic
- `index.html` — The frontend UI served by the backend

Your API key never touches the browser — it stays safely on the server.

## Deploy online (optional)

To make it accessible from anywhere, deploy to:
- **Railway** (railway.app) — free tier available
- **Render** (render.com) — free tier available  
- **Heroku** — easy Node.js deployment

Set `ANTHROPIC_API_KEY` as an environment variable on the platform and update `server.js`:
```js
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
```
