const http = require("http");
const fs = require("fs");
const path = require("path");

// ─── PUT YOUR API KEY HERE ────────────────────────────
const ANTHROPIC_API_KEY = "YOUR_API_KEY_HERE";
// ─────────────────────────────────────────────────────

const PORT = 3000;

const SYSTEM_PROMPT = `You are a world-class AI image forensics expert and prompt archaeologist. You have mastered every major AI image generator: Midjourney (all versions v1-v6.1), DALL-E 2/3, Stable Diffusion (1.5, 2.1, SDXL, Flux.1-dev, Flux.1-schnell, Pony Diffusion, Juggernaut XL), Adobe Firefly, Ideogram v1/v2, Leonardo AI, Kling, Runway Gen-3. You also have deep expertise in professional photography, classical and contemporary art history, 3D rendering (Blender, Unreal Engine 5, Octane, V-Ray), and all illustration styles.

MANDATORY 9-STEP FORENSIC ANALYSIS — mentally execute every step before writing any JSON:

STEP 1 — SOURCE DETECTION: Examine micro-characteristics. AI tells: hyperreal skin, impossible bokeh, dreamlike anatomy, Midjourney's painterly glow, SD's texture repetition, DALL-E's clean graphic style, Flux's photorealism. Real photo tells: authentic film grain, genuine lens distortion, real motion blur, candid imperfections. Identify the exact platform and version.

STEP 2 — SUBJECT INVENTORY (ultra-specific): Every human: estimated age, gender, apparent ethnicity, exact hair (color, length, texture, style), facial structure, expression (specific), body language, pose, every clothing item (garment, fabric texture, specific color name, fit, era/style), jewelry, tattoos, props. Every creature: species, markings, pose. Every object: material, color, condition.

STEP 3 — ENVIRONMENT: Exact setting type and era. Architectural style. Vegetation species. Season, weather. All background elements.

STEP 4 — COMPOSITION: Camera angle (exact). Estimated focal length. Depth of field. Foreground elements. Subject placement. Aspect ratio.

STEP 5 — LIGHTING FORENSICS: Count every light source. Direction, quality (hard/soft), color temperature in Kelvin, shadow characteristics, time of day. Special effects (god rays, volumetric fog, neon glow, lens flare).

STEP 6 — COLOR SCIENCE: 3-5 dominant hues with specific names (not "blue" but "deep cerulean"). Saturation level. Contrast style. Color grading LUT if detectable.

STEP 7 — ART STYLE FINGERPRINT: Realism spectrum. Artist influences if detectable. Genre.

STEP 8 — TECHNICAL MARKERS: Noise/grain, sharpness falloff, chromatic aberration, vignetting, render quality.

STEP 9 — PROMPT RECONSTRUCTION: Synthesize ALL findings. Use platform-native syntax:
- Midjourney: ::weight, --ar, --stylize, --v 6 etc.
- Stable Diffusion/SDXL: (keyword:1.3) weighting, quality boosters
- Flux: natural descriptive language
- Real photos: camera body, lens mm, f-stop, ISO estimates

RULES: Never be vague. Not "a woman" but "a pale-skinned woman in her late 20s with straight obsidian-black hair in a sharp bob, wearing an oversized moss-green linen trench coat". Not "dramatic lighting" but "single hard key light from camera-left at 45 degrees casting Rembrandt triangle shadow, warm 3200K tungsten fill, cool 6000K rim backlight". Mark uncertain elements with "(possibly: ...)".

OUTPUT ONLY raw JSON — no markdown, no code fences, no text before or after:
{
  "image_type": "midjourney_v6|dalle3|stable_diffusion_xl|flux_dev|real_photo|digital_painting|3d_render|oil_painting|watercolor|anime|concept_art|other",
  "confidence": <integer 0-100>,
  "prompt": "<COMPLETE ultra-detailed reconstructed prompt, minimum 100 words>",
  "negative_prompt": "<specific exclusions for SD/Flux; write N/A for real photos>",
  "style_tags": ["up to 7 style/lighting/mood tags"],
  "subject_tags": ["up to 7 subject/scene/object tags"],
  "tech_tags": ["up to 5 technical/camera/render tags"],
  "suggested_generator": "<single best AI tool to recreate this>",
  "key_details": "<2-3 sentences on the most visually distinctive elements>"
}`;

function serveFile(res, filePath, contentType) {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end("Not found");
      return;
    }
    res.writeHead(200, { "Content-Type": contentType });
    res.end(data);
  });
}

async function callAnthropic(body) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(body);
    const options = {
      hostname: "api.anthropic.com",
      path: "/v1/messages",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Length": Buffer.byteLength(postData),
      },
    };

    const req = http.request(
      { ...options, hostname: "api.anthropic.com" },
      (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve({ status: res.statusCode, body: JSON.parse(data) });
          } catch (e) {
            reject(new Error("Failed to parse Anthropic response"));
          }
        });
      }
    );

    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

// Use https for the actual Anthropic call
const https = require("https");

async function callAnthropicSecure(body) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(body);
    const options = {
      hostname: "api.anthropic.com",
      path: "/v1/messages",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Length": Buffer.byteLength(postData),
      },
    };

    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch (e) {
          reject(new Error("Failed to parse Anthropic response"));
        }
      });
    });

    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

const server = http.createServer(async (req, res) => {
  // CORS headers
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  // Serve frontend
  if (req.method === "GET" && (req.url === "/" || req.url === "/index.html")) {
    serveFile(res, path.join(__dirname, "index.html"), "text/html");
    return;
  }

  // API proxy endpoint
  if (req.method === "POST" && req.url === "/api/decode") {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", async () => {
      try {
        const { imageBase64, mimeType } = JSON.parse(body);

        if (!imageBase64 || !mimeType) {
          res.writeHead(400, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ error: "Missing imageBase64 or mimeType" }));
          return;
        }

        const result = await callAnthropicSecure({
          model: "claude-opus-4-5",
          max_tokens: 2000,
          system: SYSTEM_PROMPT,
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "image",
                  source: {
                    type: "base64",
                    media_type: mimeType,
                    data: imageBase64,
                  },
                },
                {
                  type: "text",
                  text: "Execute all 9 forensic analysis steps. Be ruthlessly specific — every visible micro-detail matters. Output ONLY the raw JSON object with no surrounding text.",
                },
              ],
            },
          ],
        });

        if (result.status !== 200) {
          res.writeHead(result.status, { "Content-Type": "application/json" });
          res.end(JSON.stringify(result.body));
          return;
        }

        const rawText = result.body.content
          .map((b) => b.text || "")
          .join("");
        const clean = rawText
          .replace(/^```json\s*/, "")
          .replace(/^```\s*/, "")
          .replace(/```\s*$/, "")
          .trim();

        let parsed;
        try {
          parsed = JSON.parse(clean);
        } catch (e) {
          const match = rawText.match(/\{[\s\S]*\}/);
          if (match) parsed = JSON.parse(match[0]);
          else throw new Error("Could not parse AI response as JSON");
        }

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(parsed));
      } catch (err) {
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end("Not found");
});

server.listen(PORT, () => {
  console.log("");
  console.log("  ╔══════════════════════════════════════╗");
  console.log("  ║        VisionPrompt Server           ║");
  console.log("  ╠══════════════════════════════════════╣");
  console.log(`  ║  Running at http://localhost:${PORT}    ║`);
  console.log("  ║  Open this URL in your browser       ║");
  console.log("  ╚══════════════════════════════════════╝");
  console.log("");

  if (ANTHROPIC_API_KEY === "YOUR_API_KEY_HERE") {
    console.log(
      "  ⚠️  WARNING: Add your Anthropic API key to server.js"
    );
    console.log(
      "     Get one at: https://console.anthropic.com/keys"
    );
    console.log("");
  } else {
    console.log("  ✓ API key loaded");
    console.log("");
  }
});
